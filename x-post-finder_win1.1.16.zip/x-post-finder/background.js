importScripts(
  'lib/shared.js',
  'lib/storage.js',
  'lib/scorer.js',
  'lib/templates.js',
  'lib/search.js'
);

/* global chrome, XGFStorage, XGFScorer, XGFTemplates, XGFSearch, XGFShared */

const SEARCH_ALARM = 'xgf-search-cycle';
const FALLBACK_RECORDING_PRESET_NAME = 'Recording Action Template';
let busy = false;
let currentSearchRunId = 0;
let activeSearchTabs = new Set();
let stopRequested = false;

function getLangText(settings, enText, zhText) {
  return XGFShared.uiText ? XGFShared.uiText(settings || {}, enText, zhText) : enText;
}

function normalizeTweetUrl(url) {
  return XGFShared.normalizeTweetUrl(url);
}

function sameTweetUrl(a, b) {
  const ia = XGFShared.extractTweetIdentity(a);
  const ib = XGFShared.extractTweetIdentity(b);
  return !!ia.tweetId && ia.tweetId === ib.tweetId &&
    (!ia.handle || !ib.handle || ia.handle.replace(/^@/, '') === ib.handle.replace(/^@/, ''));
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function closeActiveSearchTabs() {
  const tabs = Array.from(activeSearchTabs);
  activeSearchTabs = new Set();
  for (const tabId of tabs) {
    try { await chrome.tabs.remove(tabId); } catch {}
  }
}

async function clearXgfNotifications() {
  const all = await chrome.notifications.getAll().catch(() => ({}));
  for (const id of Object.keys(all || {})) {
    if (!String(id).startsWith('xgf-')) continue;
    try { await chrome.notifications.clear(id); } catch {}
  }
}

async function broadcastContentControl(type) {
  const tabs = await chrome.tabs.query({ url: ['https://x.com/*', 'https://twitter.com/*'] }).catch(() => []);
  const tasks = [];
  for (const tab of tabs || []) {
    if (!tab?.id) continue;
    tasks.push(chrome.tabs.sendMessage(tab.id, { type }).catch(() => null));
  }
  return Promise.all(tasks);
}

function isSearchAborted(runId) {
  return stopRequested || runId !== currentSearchRunId;
}

async function requestForceStop(reason = 'manual') {
  stopRequested = true;
  currentSearchRunId += 1;
  try { await chrome.alarms.clear(SEARCH_ALARM); } catch {}
  try {
    const state = await XGFStorage.getState();
    const patch = {
      searchPaused: true,
      forceStopped: true,
      forceStopReason: reason || 'manual',
      forceStoppedAt: Date.now()
    };
    if (!state.settings.searchPaused || !state.settings.forceStopped || state.settings.forceStopReason !== patch.forceStopReason) {
      await XGFStorage.updateSettings(patch);
    }
  } catch {}
  await clearXgfNotifications();
  await closeActiveSearchTabs();
  await broadcastContentControl('xgf:stop_all');
  return { ok: true, stopped: true, reason };
}

async function requestResumeBroadcast() {
  stopRequested = false;
  try {
    const state = await XGFStorage.getState();
    if (state.settings.forceStopped || state.settings.searchPaused) {
      await XGFStorage.updateSettings({
        forceStopped: false,
        forceStopReason: '',
        forceStoppedAt: null,
        searchPaused: false
      });
    }
  } catch {}
  await scheduleAlarms();
  return { ok: true };
}

async function ensureDefaults() {
  const state = await XGFStorage.getState();
  if (!state.settings) {
    await XGFStorage.setState({
      settings: XGFShared.buildDefaultSettings(),
      candidates: [],
      actions: [],
      stats: { scanned: 0, matched: 0, lastSearchAt: null }
    });
    return;
  }
  await XGFStorage.pruneHistory(state.settings.preserveHistoryDays || 30);
}

async function syncContentState() {
  if (stopRequested) {
    await broadcastContentControl('xgf:stop_all');
    return false;
  }
  const state = await XGFStorage.getState();
  const shouldRun = !!state.settings.enabled && !!state.settings.autoSearch && !state.settings.searchPaused && !state.settings.forceStopped;
  if (shouldRun) {
    await broadcastContentControl('xgf:resume_all');
  } else {
    await broadcastContentControl('xgf:stop_all');
  }
  return shouldRun;
}

async function scheduleAlarms() {
  let state = await XGFStorage.getState();
  const desiredRun = !!state.settings.enabled && !!state.settings.autoSearch && !state.settings.searchPaused;
  let forceStopped = !!state.settings.forceStopped;

  try { await chrome.alarms.clear(SEARCH_ALARM); } catch {}

  if (stopRequested && desiredRun) {
    stopRequested = false;
    await broadcastContentControl('xgf:resume_all');
  } else if (stopRequested) {
    await broadcastContentControl('xgf:stop_all');
    return { skipped: true, reason: 'stopped' };
  }

  if (desiredRun && forceStopped) {
    try {
      await XGFStorage.updateSettings({
        forceStopped: false,
        forceStopReason: '',
        forceStoppedAt: null
      });
      state = await XGFStorage.getState();
      forceStopped = !!state.settings.forceStopped;
    } catch {}
  }

  const shouldRun = desiredRun && !stopRequested && !forceStopped;
  if (shouldRun) {
    await broadcastContentControl('xgf:resume_all');
    const interval = Math.max(5, Number(state.settings.searchIntervalMinutes || 15));
    await chrome.alarms.create(SEARCH_ALARM, { periodInMinutes: interval });
    return { ok: true };
  }

  await broadcastContentControl('xgf:stop_all');
  return {
    paused: !!state.settings.searchPaused,
    disabled: !state.settings.enabled,
    autoSearchOff: !state.settings.autoSearch,
    forceStopped
  };
}

async function openSearchTab(query) {
  const url = XGFSearch.buildSearchUrl(query);
  const tab = await chrome.tabs.create({ url, active: false });
  return tab;
}

async function waitForTabComplete(tabId, timeoutMs = 15000, shouldAbort = () => false) {
  const startedAt = Date.now();
  const current = await chrome.tabs.get(tabId).catch(() => null);
  if (current?.status === 'complete') return true;
  if (shouldAbort()) return false;

  return await new Promise(resolve => {
    const onUpdated = (updatedTabId, changeInfo, tab) => {
      if (shouldAbort()) {
        cleanup(false);
        return;
      }
      if (updatedTabId !== tabId) return;
      if (changeInfo.status === 'complete' || tab?.status === 'complete') {
        cleanup(true);
      }
    };

    const timer = setInterval(async () => {
      if (shouldAbort()) {
        cleanup(false);
        return;
      }
      const tab = await chrome.tabs.get(tabId).catch(() => null);
      if (tab?.status === 'complete') cleanup(true);
      if (Date.now() - startedAt > timeoutMs) cleanup(false);
    }, 500);

    function cleanup(result) {
      clearInterval(timer);
      try { chrome.tabs.onUpdated.removeListener(onUpdated); } catch {}
      resolve(result);
    }

    chrome.tabs.onUpdated.addListener(onUpdated);
    setTimeout(() => cleanup(false), timeoutMs);
  });
}


async function findTabForTweetUrl(targetUrl) {
  if (!targetUrl) return null;
  const normalizedTarget = normalizeTweetUrl(targetUrl);
  const targetIdentity = XGFShared.extractTweetIdentity(normalizedTarget);
  const tabs = await chrome.tabs.query({});
  return tabs.find(t => {
    if (!t?.url) return false;
    if (normalizeTweetUrl(t.url) === normalizedTarget) return true;
    const tabIdentity = XGFShared.extractTweetIdentity(t.url);
    return !!targetIdentity.tweetId && tabIdentity.tweetId === targetIdentity.tweetId;
  }) || null;
}

async function ensureTweetTab(targetUrl) {
  if (!targetUrl) return null;
  const tab = await chrome.tabs.create({ url: targetUrl, active: true });
  await waitForTabComplete(tab.id, 20000);
  return tab;
}

async function runSearchCycle(options = {}) {
  const state = await XGFStorage.getState();
  const force = !!options.force;
  if (!state.settings.enabled) return { skipped: true, reason: 'disabled' };
  if (stopRequested) return { skipped: true, reason: 'stopped' };
  if (!force && !state.settings.autoSearch) return { skipped: true, reason: 'auto_search_off' };
  if (state.settings.searchPaused && !force) return { skipped: true, reason: 'paused' };
  if (busy) return { skipped: true, reason: 'busy' };

  busy = true;
  const runId = ++currentSearchRunId;
  const openedTabs = [];
  activeSearchTabs = new Set();
  try {
    const queries = XGFSearch.buildSearchQueries(state.settings);
    const limited = queries.slice(0, Math.min(20, Math.max(1, queries.length)));

    for (const query of limited) {
      if (isSearchAborted(runId)) return { skipped: true, reason: 'stopped' };
      const tab = await openSearchTab(query);
      if (tab?.id) {
        openedTabs.push(tab.id);
        activeSearchTabs.add(tab.id);
      }

      const completed = tab?.id ? await waitForTabComplete(tab.id, 18000, () => isSearchAborted(runId)) : false;
      if (isSearchAborted(runId)) return { skipped: true, reason: 'stopped' };
      if (!completed) {
        await sleep(300);
      } else {
        await sleep(1200);
      }

      try {
        if (tab?.id && !isSearchAborted(runId)) {
          await chrome.tabs.sendMessage(tab.id, {
            type: 'xgf:auto_search_cycle',
            options: {
              maxResults: Number(state.settings.maxSearchResultsPerCycle || 200),
              scrollCycles: Number(state.settings.searchScrollCycles || 4),
              delayMs: Number(state.settings.searchScrollDelayMs || 1200),
            }
          });
        }
      } catch {
        try {
          if (tab?.id && !isSearchAborted(runId)) {
            await chrome.tabs.sendMessage(tab.id, { type: 'xgf:scan_visible' });
          }
        } catch {}
      } finally {
        if (tab?.id) {
          activeSearchTabs.delete(tab.id);
          try { await chrome.tabs.remove(tab.id); } catch {}
        }
      }

      if (isSearchAborted(runId)) return { skipped: true, reason: 'stopped' };
      await sleep(800);
    }

    return { ok: true, searched: limited.length };
  } finally {
    for (const tabId of openedTabs.reverse()) {
      activeSearchTabs.delete(tabId);
      try { await chrome.tabs.remove(tabId); } catch {}
    }
    busy = false;
  }
}

async function notifyCandidate(item) {
  const state = await XGFStorage.getState();
  if (!state.settings.enabled) return;

  const title = getLangText(state.settings, `Post found · ${item.score} pts`, `发现帖子 · ${item.score} 分`);
  const message = getLangText(state.settings, `${item.author || item.handle || 'Unknown author'}: ${(item.text || '').slice(0, 90)}`, `${item.author || item.handle || '未知作者'}：${(item.text || '').slice(0, 90)}`);

  await chrome.notifications.create(`xgf-${item.id}`, {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title,
    message,
    priority: 1,
    silent: !state.settings.notificationSound,
  });
}

async function ingestTweets(tweets, pageUrl = '') {
  const state = await XGFStorage.getState();
  const filtered = [];
  const scannedCount = Array.isArray(tweets) ? tweets.length : 0;
  const cutoff = XGFShared.parseLocalDateTime(state.settings.collectAfterDate);
  const existingIds = new Set((state.candidates || []).map(item => String(item?.id || '')));

  for (const tweet of tweets || []) {
    if (!tweet || !tweet.id) continue;
    if (cutoff && tweet.createdAt && tweet.createdAt < cutoff) continue;

    const evaluated = XGFScorer.scoreTweet(tweet, state.settings);
    const item = {
      ...tweet,
      ...evaluated,
      pageUrl,
      commentTemplate: XGFTemplates.buildCommentTemplate(tweet, state.settings),
      scannedAt: Date.now(),
    };
    if (!evaluated.shouldStore) continue;
    filtered.push(item);
  }

  await XGFStorage.addScannedCount(scannedCount);
  if (!filtered.length) return { matched: 0, scanned: scannedCount };

  await XGFStorage.upsertCandidates(filtered);

  for (const item of filtered) {
    const isNew = !existingIds.has(String(item.id || ''));
    if (isNew && item.score >= (state.settings.notificationThreshold || 72)) {
      await notifyCandidate(item);
    }
  }

  if (state.settings.autoOpenBestMatch) {
    const best = filtered.sort((a, b) => b.score - a.score)[0];
    if (best?.url) await chrome.tabs.create({ url: best.url, active: true });
  }

  return { matched: filtered.length };
}

async function saveActionProfile(action, profile) {
  const state = await XGFStorage.getState();
  const nextProfiles = { ...XGFShared.sanitizeActionProfiles(state.settings.actionProfiles), [action]: profile };
  const activeName = String(state.settings.activePresetName || '').trim();
  const presetName = activeName || FALLBACK_RECORDING_PRESET_NAME;

  let nextPresets = Array.isArray(state.settings.savedPresets)
    ? state.settings.savedPresets.map(preset => {
        if (preset.name !== presetName) return preset;
        return {
          ...preset,
          settings: { ...(preset.settings || {}), actionProfiles: nextProfiles }
        };
      })
    : [];

  const presetSettings = {
    ...state.settings,
    actionProfiles: nextProfiles,
    savedPresets: [],
    activePresetName: presetName
  };
  delete presetSettings.savedPresets;
  delete presetSettings.activePresetName;

  const updatedPreset = {
    name: presetName,
    settings: presetSettings,
    savedAt: Date.now(),
    version: 1
  };

  const existingIndex = nextPresets.findIndex(preset => preset.name === presetName);
  if (existingIndex >= 0) {
    nextPresets[existingIndex] = updatedPreset;
  } else {
    nextPresets.unshift(updatedPreset);
  }

  await XGFStorage.updateSettings({
    actionProfiles: nextProfiles,
    savedPresets: nextPresets,
    activePresetName: presetName
  });

  return { actionProfiles: nextProfiles, presetName };
}


async function saveRecordedAction(message) {
  const state = await XGFStorage.getState();
  const { action, profile } = message || {};
  if (!action || !profile) return { ok: false, error: 'Invalid recording result' };
  const saved = await saveActionProfile(action, profile);
  try {
    await chrome.notifications.create(`xgf-recorded-${action}-${Date.now()}`, {
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: getLangText(state, `Recorded ${action}`, `已录制 ${action}`),
      message: saved?.presetName
        ? getLangText(state, `Saved to current settings and synced to preset "${saved.presetName}".`, `已保存到当前设置，并同步到预设「${saved.presetName}」。`)
        : getLangText(state, 'Saved to current settings.', '已保存到当前设置中。'),
      priority: 1,
      silent: true,
    });
  } catch {}
  return { ok: true, profile, presetName: saved?.presetName || '' };
}

async function startRecordingOnActiveTab(action) {
  const state = await XGFStorage.getState();
  const targetAction = String(action || '').trim();
  if (!targetAction) return { ok: false, error: 'Recording type cannot be empty' };

  const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  let tab = null;
  if (activeTab?.id && /^https:\/\/(x|twitter)\.com/.test(activeTab.url || '')) {
    tab = activeTab;
  } else {
    const xTabs = await chrome.tabs.query({ url: ['https://x.com/*', 'https://twitter.com/*'] });
    if (xTabs.length === 1) {
      tab = xTabs[0];
    } else if (xTabs.length > 1) {
      return { ok: false, error: 'Please switch to the X page you want to record, then click the record button' };
    }
  }

  if (!tab?.id) return { ok: false, error: 'Please open an X (Twitter) page first' };

  const res = await chrome.tabs.sendMessage(tab.id, {
    type: 'xgf:start_record_action',
    action: targetAction
  }).catch(err => ({ ok: false, error: String(err) }));

  if (!res?.ok) return res || { ok: false, error: 'Could not start recording on the current page' };

  try {
    await chrome.notifications.create(`xgf-record-start-${targetAction}-${Date.now()}`, {
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: getLangText(state, `Record ${targetAction}`, `录制 ${targetAction}`),
      message: getLangText(state, 'Please perform the matching action once on X, and the extension will capture the button structure.', '请在 X 页面完成一次对应操作，插件会自动记录按钮结构。'),
      priority: 1,
      silent: true,
    });
  } catch {}

  return { ok: true, message: getLangText(state.settings, 'Recording started', '录制已开始') };
}

async function handleRecordAction(message) {
  return await startRecordingOnActiveTab(message?.action);
}

chrome.runtime.onInstalled.addListener(async () => {
  await ensureDefaults();
  await scheduleAlarms();
});

chrome.runtime.onStartup.addListener(async () => {
  await ensureDefaults();
  await scheduleAlarms();
});

chrome.alarms.onAlarm.addListener(async alarm => {
  if (alarm.name === SEARCH_ALARM) {
    await runSearchCycle();
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !message.type) return;

  if (message.type === 'xgf:candidates') {
    ingestTweets(message.tweets || [], message.pageUrl || sender?.tab?.url || '')
      .then(result => sendResponse({ ok: true, ...result }))
      .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true;
  }

  if (message.type === 'xgf:get_state') {
    XGFStorage.getState()
      .then(state => sendResponse({ ok: true, state }))
      .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true;
  }

  if (message.type === 'xgf:run_search') {
    runSearchCycle({ force: true })
      .then(result => sendResponse({ ok: true, result }))
      .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true;
  }

  if (message.type === 'xgf:refresh_alarm') {
    scheduleAlarms()
      .then(result => sendResponse({ ok: true, result }))
      .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true;
  }

  if (message.type === 'xgf:force_stop') {
    requestForceStop(message.reason)
      .then(result => sendResponse(result))
      .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true;
  }

  if (message.type === 'xgf:resume_all') {
    requestResumeBroadcast()
      .then(result => sendResponse(result))
      .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true;
  }

  if (message.type === 'xgf:update_settings') {
    XGFStorage.updateSettings(message.patch || {})
      .then(async settings => {
        await scheduleAlarms();
        sendResponse({ ok: true, settings });
      })
      .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true;
  }

  if (message.type === 'xgf:save_preset') {
    XGFStorage.savePreset(message.name, message.settings)
      .then(presets => sendResponse({ ok: true, presets }))
      .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true;
  }

  if (message.type === 'xgf:delete_preset') {
    XGFStorage.deletePreset(message.name)
      .then(presets => sendResponse({ ok: true, presets }))
      .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true;
  }

  if (message.type === 'xgf:apply_preset') {
    XGFStorage.applyPreset(message.name)
      .then(settings => sendResponse({ ok: true, settings }))
      .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true;
  }

  if (message.type === 'xgf:export_preset') {
    XGFStorage.exportPreset(message.name)
      .then(json => sendResponse({ ok: true, json }))
      .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true;
  }

  if (message.type === 'xgf:import_preset') {
    XGFStorage.importPreset(message.payload)
      .then(result => sendResponse({ ok: true, ...result }))
      .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true;
  }

  if (message.type === 'xgf:record_action') {
    handleRecordAction(message)
      .then(result => sendResponse(result))
      .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true;
  }

  if (message.type === 'xgf:commit_recorded_action') {
    saveRecordedAction(message)
      .then(result => sendResponse(result))
      .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true;
  }

  if (message.type === 'xgf:perform_action') {
    (async () => {
      try {
        const action = String(message.payload?.action || '').trim();
        const tweetUrl = message.payload?.tweetUrl || '';
        if (!action) return sendResponse({ ok: false, error: 'Action cannot be empty' });

        if (action === 'open') {
          if (!tweetUrl) return sendResponse({ ok: false, error: 'Missing original post URL' });
          await chrome.tabs.create({ url: normalizeTweetUrl(tweetUrl), active: true });
          return sendResponse({ ok: true });
        }

        let tab = await findTabForTweetUrl(tweetUrl);
        if ((!tab || !tab.id || !/^https:\/\/(x|twitter)\.com/.test(tab.url || '')) && tweetUrl) {
          tab = await ensureTweetTab(normalizeTweetUrl(tweetUrl));
        }
        if (!tab?.id) return sendResponse({ ok: false, error: 'Current tab not found' });
        const res = await chrome.tabs.sendMessage(tab.id, { type: 'xgf:perform_action', payload: message.payload });
        sendResponse(res || { ok: false, error: 'No response' });
      } catch (err) {
        sendResponse({ ok: false, error: String(err) });
      }
    })();
    return true;
  }
});

chrome.notifications.onClicked.addListener(async id => {
  if (!id.startsWith('xgf-')) return;
  const state = await XGFStorage.getState();
  const candidate = state.candidates.find(item => `xgf-${item.id}` === id);
  if (candidate?.url) {
    await chrome.tabs.create({ url: candidate.url, active: true });
  }
});
