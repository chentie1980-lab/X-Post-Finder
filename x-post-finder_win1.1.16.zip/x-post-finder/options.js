/* global chrome, XGFStorage, XGFShared */
const $ = s => document.querySelector(s);
const status = $('#status');
let liveSettings = null;

function currentLang(settings = liveSettings || {}) {
  return window.XGFShared?.getUILanguage ? XGFShared.getUILanguage(settings) : (settings.uiLanguage === 'zh' ? 'zh' : 'en');
}
function L(enText, zhText) {
  return window.XGFShared?.uiText ? XGFShared.uiText(liveSettings || {}, enText, zhText) : enText;
}
function setText(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}
function setOptionLabel(selectId, value, text) {
  const select = document.getElementById(selectId);
  if (!select) return;
  const opt = Array.from(select.options).find(o => o.value === value);
  if (opt) opt.textContent = text;
}
function defaultCommentTemplate(lang) {
  return lang === 'zh'
    ? '已关注并转发，期待中奖！'
    : 'Followed and reposted — hoping to win!';
}

function previewTheme() {
  if (!window.XGFShared?.applyTheme) return;
  XGFShared.applyTheme(document.documentElement, {
    themeMode: $('#themeMode')?.value || 'auto',
    accentColor: $('#accentColor')?.value || 'blue'
  });
}

function fillList(id, arr) {
  $(id).value = (arr || []).join('\n');
}
function readList(id) {
  return $(id).value.split('\n').map(s => s.trim()).filter(Boolean);
}
function populatePresetSelect(presets = []) {
  const select = $('#presetSelect');
  select.innerHTML = '';
  const placeholder = document.createElement('option');
  placeholder.value = '';
  placeholder.textContent = presets.length
    ? L('Select a preset', '请选择预设')
    : L('No presets yet', '暂无预设');
  select.appendChild(placeholder);
  for (const preset of presets) {
    const opt = document.createElement('option');
    opt.value = preset.name;
    opt.textContent = `${preset.name}`;
    select.appendChild(opt);
  }
}
function localDateTimeInputToISO(value) {
  if (!value) return '';
  const d = new Date(value);
  return Number.isFinite(d.getTime()) ? d.toISOString() : '';
}
function isoToLocalDateTimeInput(value) {
  if (!value) return '';
  const d = new Date(value);
  if (!Number.isFinite(d.getTime())) return '';
  const pad = n => String(n).padStart(2, '0');
  const tzOffset = d.getTimezoneOffset() * 60000;
  const local = new Date(d.getTime() - tzOffset);
  return `${local.getFullYear()}-${pad(local.getMonth() + 1)}-${pad(local.getDate())}T${pad(local.getHours())}:${pad(local.getMinutes())}`;
}

function applyLanguageToPage(settings = liveSettings || {}) {
  const lang = currentLang(settings);
  document.documentElement.lang = lang === 'zh' ? 'zh-CN' : 'en';
  document.title = lang === 'zh' ? 'X Post Finder · 设置' : 'X Post Finder · Settings';

  if (lang === 'zh') {
    setText('pageTitle', '设置');
    setText('lead', '这里配置自动搜索、评分规则、收录时间、评论模板和预设。');
    setText('appearanceHeading', '外观');
    setText('appearanceSub', '整体会尽量保持克制、干净、留白足一点。');
    setText('lblThemeMode', '界面模式');
    setText('lblAccentColor', '主色');
    setText('lblUiLanguage', '界面语言');
    setText('appearanceHelp', '整体会尽量保持克制、干净、留白足一点，不会做得花里胡哨。');

    setText('lblEnabled', '启用插件');
    setText('lblAutoSearch', '启用后台自动搜索');
    setText('lblNotificationSound', '通知提醒');
    setText('lblAutoOpenBestMatch', '自动打开最佳结果');
    setText('lblSearchPaused', '暂停后台自动搜索');
    setText('lblMultilangMode', '多语言模式');

    setText('lblSearchInterval', '搜索间隔（分钟）');
    setText('lblNotificationThreshold', '通知阈值');
    setText('lblMinScore', '最小收录分数');
    setText('lblMaxCandidates', '最大保存条数');
    setText('lblMaxSearchResultsPerCycle', '每轮最大搜索结果');
    setText('lblSearchScrollCycles', '自动滚动次数');
    setText('lblSearchScrollDelayMs', '滚动间隔（毫秒）');
    setText('lblCollectAfterDate', '收录截止时间');
    setText('lblPreserveHistoryDays', '历史保留天数');

    setText('commentHeading', '评论模板');
    setText('commentSub', '用于快速复制和一键操作。');
    setText('lblScoreRules', '评分规则');
    setText('scoringHeading', '评分与搜索');
    setText('scoringSub', '每行一条，格式为 关键词:分数。');
    setText('lblKeywords', '关键词');
    setText('lblNegativeKeywords', '排除词');
    setText('lblSearchNoiseTerms', '搜索噪声词');
    setText('lblLanguages', '语言');

    setText('presetHeading', '预设');
    setText('presetSub', '评分规则也会随预设一起保存与分享。');
    setText('presetName', '');
    setText('savePreset', '保存当前设置为预设');
    setText('applyPreset', '应用预设');
    setText('deletePreset', '删除预设');
    setText('copyPreset', '复制预设 JSON');
    setText('loadPresetJson', '从 JSON 导入');
    setText('lblPresetJson', '预设 JSON');
    setText('presetHelp', '分享方式：把预设 JSON 发给别人，对方粘贴后点击导入即可。');

    setText('recordHeading', '动作录制');
    setText('recordSub', '当点赞 / 转发 / 评论 / 关注按钮失效时先录制一次。');
    setText('recordLike', '录制点赞');
    setText('recordRepost', '录制转发');
    setText('recordComment', '录制评论');
    setText('recordFollow', '录制关注');

    setText('save', '保存');
    setText('runNow', '立即后台搜索');
    setText('forceStop', '强制停止');
    setText('reset', '恢复默认');

    setOptionLabel('themeMode', 'auto', '跟随系统');
    setOptionLabel('themeMode', 'light', '浅色');
    setOptionLabel('themeMode', 'dark', '深色');
    setOptionLabel('accentColor', 'blue', '蓝色');
    setOptionLabel('accentColor', 'sky', '青蓝');
    setOptionLabel('accentColor', 'violet', '紫色');
    setOptionLabel('accentColor', 'green', '绿色');
    setOptionLabel('accentColor', 'rose', '玫瑰');
    setOptionLabel('accentColor', 'amber', '琥珀');
    setOptionLabel('accentColor', 'slate', '石墨');
    setOptionLabel('uiLanguage', 'en', 'English');
    setOptionLabel('uiLanguage', 'zh', '中文');

    $('#commentTemplate').placeholder = '用于复制评论和一键操作的模板';
    $('#scoreRulesText').placeholder = '帖子:20';
    $('#keywords').placeholder = '每行一个关键词';
    $('#negativeKeywords').placeholder = '每行一个排除词';
    $('#searchNoiseTerms').placeholder = '每行一个搜索噪声词';
    $('#languages').placeholder = '如 en\\nzh';
    $('#presetName').placeholder = '预设名称';
    $('#presetJson').placeholder = '粘贴预设 JSON 后导入';
    $('#uiLanguage').title = '切换界面语言';
  } else {
    setText('pageTitle', 'Settings');
    setText('lead', 'Configure automatic search, scoring rules, capture time, comment templates, and presets.');
    setText('appearanceHeading', 'Appearance');
    setText('appearanceSub', 'Keep the interface clean and close to a browser tab feel.');
    setText('lblThemeMode', 'Interface mode');
    setText('lblAccentColor', 'Accent color');
    setText('lblUiLanguage', 'Interface language');
    setText('appearanceHelp', 'The layout stays restrained, clean, and spacious.');

    setText('lblEnabled', 'Enable extension');
    setText('lblAutoSearch', 'Enable background auto search');
    setText('lblNotificationSound', 'Notification sound');
    setText('lblAutoOpenBestMatch', 'Auto-open best match');
    setText('lblSearchPaused', 'Pause background auto search');
    setText('lblMultilangMode', 'Multilingual mode');

    setText('lblSearchInterval', 'Search interval (minutes)');
    setText('lblNotificationThreshold', 'Notification threshold');
    setText('lblMinScore', 'Minimum stored score');
    setText('lblMaxCandidates', 'Max stored records');
    setText('lblMaxSearchResultsPerCycle', 'Max search results per run');
    setText('lblSearchScrollCycles', 'Auto-scroll cycles');
    setText('lblSearchScrollDelayMs', 'Scroll delay (ms)');
    setText('lblCollectAfterDate', 'Collect after');
    setText('lblPreserveHistoryDays', 'History retention (days)');

    setText('commentHeading', 'Comment template');
    setText('commentSub', 'Used for quick copy and one-click actions.');
    setText('lblScoreRules', 'Scoring rules');
    setText('scoringHeading', 'Scoring and search');
    setText('scoringSub', 'One line per rule in the form keyword:score.');
    setText('lblKeywords', 'Keywords');
    setText('lblNegativeKeywords', 'Negative keywords');
    setText('lblSearchNoiseTerms', 'Search noise terms');
    setText('lblLanguages', 'Languages');

    setText('presetHeading', 'Presets');
    setText('presetSub', 'Scoring rules are saved and shared with presets.');
    setText('savePreset', 'Save current as preset');
    setText('applyPreset', 'Apply preset');
    setText('deletePreset', 'Delete preset');
    setText('copyPreset', 'Copy preset JSON');
    setText('loadPresetJson', 'Import from JSON');
    setText('lblPresetJson', 'Preset JSON');
    setText('presetHelp', 'Share a preset by sending the JSON to someone else, then import it on their side.');

    setText('recordHeading', 'Action recording');
    setText('recordSub', 'Re-record once when like / repost / comment / follow buttons stop working.');
    setText('recordLike', 'Record like');
    setText('recordRepost', 'Record repost');
    setText('recordComment', 'Record comment');
    setText('recordFollow', 'Record follow');

    setText('save', 'Save');
    setText('runNow', 'Run search now');
    setText('forceStop', 'Force stop');
    setText('reset', 'Restore defaults');

    $('#commentTemplate').placeholder = 'Template used for comment copy and one-click actions';
    $('#scoreRulesText').placeholder = 'post:20';
    $('#keywords').placeholder = 'One keyword per line';
    $('#negativeKeywords').placeholder = 'One keyword per line';
    $('#searchNoiseTerms').placeholder = 'One keyword per line';
    $('#languages').placeholder = 'e.g. en\\nzh';
    $('#presetName').placeholder = 'Preset name';
    $('#presetJson').placeholder = 'Paste a preset JSON here, or copy one to share it.';
  }

  const presetSelect = $('#presetSelect');
  if (presetSelect && presetSelect.options.length) {
    presetSelect.options[0].textContent = presetSelect.value
      ? L('Select a preset', '请选择预设')
      : L('No presets yet', '暂无预设');
  }

  // keep the selected values intact while updating option text
  if ($('#uiLanguage')) $('#uiLanguage').value = lang;
  if ($('#themeMode')) $('#themeMode').value = $('#themeMode').value || 'auto';
  if ($('#accentColor')) $('#accentColor').value = $('#accentColor').value || 'blue';
}

function syncPresetButtons() {
  const select = $('#presetSelect');
  const hasValue = !!select.value;
  $('#applyPreset').disabled = !hasValue;
  $('#deletePreset').disabled = !hasValue;
}

function syncPresetJson() {
  const name = $('#presetSelect').value;
  const jsonBox = $('#presetJson');
  if (!name) {
    jsonBox.value = '';
    return;
  }
  XGFStorage.exportPreset(name)
    .then(json => {
      jsonBox.value = json;
    })
    .catch(err => {
      jsonBox.value = '';
      status.textContent = L(`Export preset failed: ${err}`, `导出预设失败：${err}`);
    });
}

async function load() {
  const state = await XGFStorage.getState();
  const s = state.settings || XGFShared.buildDefaultSettings();
  liveSettings = s;

  $('#enabled').checked = !!s.enabled;
  $('#autoSearch').checked = !!s.autoSearch;
  $('#notificationSound').checked = !!s.notificationSound;
  $('#autoOpenBestMatch').checked = !!s.autoOpenBestMatch;
  $('#searchPaused').checked = !!s.searchPaused;
  $('#multilangMode').checked = !!s.multilangMode;
  $('#searchIntervalMinutes').value = s.searchIntervalMinutes ?? 15;
  $('#minScore').value = s.minScore ?? 55;
  $('#notificationThreshold').value = s.notificationThreshold ?? 72;
  $('#maxCandidates').value = s.maxCandidates ?? 300;
  $('#maxSearchResultsPerCycle').value = s.maxSearchResultsPerCycle ?? 200;
  $('#searchScrollCycles').value = s.searchScrollCycles ?? 4;
  $('#searchScrollDelayMs').value = s.searchScrollDelayMs ?? 1200;
  $('#collectAfterDate').value = isoToLocalDateTimeInput(s.collectAfterDate);
  $('#preserveHistoryDays').value = s.preserveHistoryDays ?? 30;
  $('#commentTemplate').value = s.commentTemplate || '';
  $('#scoreRulesText').value = s.scoreRulesText || '';
  $('#uiLanguage').value = s.uiLanguage || 'en';
  if ($('#themeMode')) $('#themeMode').value = s.themeMode || 'auto';
  if ($('#accentColor')) $('#accentColor').value = s.accentColor || 'blue';
  fillList('#keywords', s.keywords);
  fillList('#negativeKeywords', s.negativeKeywords);
  fillList('#searchNoiseTerms', s.searchNoiseTerms);
  fillList('#languages', s.languages);
  populatePresetSelect(s.savedPresets || []);
  $('#presetSelect').value = s.activePresetName || '';
  syncPresetButtons();
  syncPresetJson();
  applyLanguageToPage(s);
  previewTheme();
  if (s.forceStopped && status) {
    status.textContent = window.XGFShared?.describeSearchState ? `${L('Current status:', '当前状态：')} ${XGFShared.describeSearchState(s)}` : L('Current status: force stopped', '当前状态：强制停止中');
  } else if (status) {
    status.textContent = '';
  }
}

function snapshotSettings() {
  return {
    enabled: $('#enabled').checked,
    autoSearch: $('#autoSearch').checked,
    notificationSound: $('#notificationSound').checked,
    autoOpenBestMatch: $('#autoOpenBestMatch').checked,
    searchPaused: $('#searchPaused').checked,
    multilangMode: $('#multilangMode').checked,
    searchIntervalMinutes: Number($('#searchIntervalMinutes').value || 15),
    minScore: Number($('#minScore').value || 55),
    notificationThreshold: Number($('#notificationThreshold').value || 72),
    maxCandidates: Number($('#maxCandidates').value || 300),
    maxSearchResultsPerCycle: Number($('#maxSearchResultsPerCycle').value || 200),
    searchScrollCycles: Number($('#searchScrollCycles').value || 4),
    searchScrollDelayMs: Number($('#searchScrollDelayMs').value || 1200),
    collectAfterDate: localDateTimeInputToISO($('#collectAfterDate').value),
    preserveHistoryDays: Number($('#preserveHistoryDays').value || 30),
    commentTemplate: $('#commentTemplate').value.trim(),
    scoreRulesText: $('#scoreRulesText').value.trim(),
    themeMode: $('#themeMode').value,
    accentColor: $('#accentColor').value,
    uiLanguage: $('#uiLanguage').value,
    keywords: readList('#keywords'),
    negativeKeywords: readList('#negativeKeywords'),
    searchNoiseTerms: readList('#searchNoiseTerms'),
    languages: readList('#languages'),
  };
}

async function save() {
  const patch = snapshotSettings();
  const state = await XGFStorage.getState();
  const activePresetName = state.settings?.activePresetName || '';
  const merged = {
    ...state.settings,
    ...patch,
    actionProfiles: XGFShared.sanitizeActionProfiles(state.settings?.actionProfiles || XGFShared.buildDefaultSettings().actionProfiles),
    activePresetName
  };
  await XGFStorage.updateSettings(merged);
  liveSettings = merged;
  await chrome.runtime.sendMessage({ type: 'xgf:refresh_alarm' });
  await load();
  $('#presetSelect').value = activePresetName;
  syncPresetButtons();
  syncPresetJson();
  status.textContent = L('Saved', '已保存');
}

$('#save').addEventListener('click', async () => {
  try { await save(); } catch (e) { status.textContent = L(`Save failed: ${e}`, `保存失败：${e}`); }
});

$('#runNow').addEventListener('click', async () => {
  try {
    status.textContent = L('Triggering search…', '正在触发搜索…');
    const res = await chrome.runtime.sendMessage({ type: 'xgf:run_search' });
    if (res?.result?.skipped) {
      if (res.result.reason === 'stopped') {
        status.textContent = L('The extension is force-stopped. Resume it first.', '当前处于强制停止状态，请先恢复后台搜索');
      } else if (res.result.reason === 'paused') {
        status.textContent = L('It is paused, but a manual run is still allowed.', '当前为暂停状态，但手动搜索仍可执行');
      } else if (res.result.reason === 'auto_search_off') {
        status.textContent = L('Background auto search is off and cannot run.', '后台自动搜索已关闭，无法运行');
      } else if (res.result.reason === 'disabled') {
        status.textContent = L('The extension is disabled and cannot run.', '插件已关闭，无法运行');
      } else {
        status.textContent = L(`Search not run: ${res.result.reason || 'unknown reason'}`, `搜索未执行：${res.result.reason || '未知原因'}`);
      }
    } else {
      status.textContent = L('Background search triggered', '已触发后台搜索');
    }
  } catch (err) {
    status.textContent = L(`Search failed: ${err}`, `触发搜索失败：${err}`);
  }
});

$('#forceStop').addEventListener('click', async () => {
  try {
    status.textContent = L('Forcing stop…', '正在强制停止…');
    const res = await chrome.runtime.sendMessage({ type: 'xgf:force_stop', reason: 'options' });
    if (res?.ok) {
      await load();
      status.textContent = L('Force stop applied: search, notifications, and page scanning are paused.', '已强制停止：搜索、通知和页面扫描已暂停');
    } else {
      status.textContent = res?.error || L('Force stop failed', '强制停止失败');
    }
  } catch (err) {
    status.textContent = L(`Force stop failed: ${err}`, `强制停止失败：${err}`);
  }
});

$('#reset').addEventListener('click', async () => {
  const defaults = XGFShared.buildDefaultSettings();
  await XGFStorage.setState({ settings: defaults, candidates: [], actions: [], stats: { scanned: 0, matched: 0, lastSearchAt: null } });
  await chrome.runtime.sendMessage({ type: 'xgf:refresh_alarm' });
  await load();
  status.textContent = L('Restored defaults', '已恢复默认');
});

$('#savePreset').addEventListener('click', async () => {
  const name = $('#presetName').value.trim();
  if (!name) {
    status.textContent = L('Please enter a preset name', '请输入预设名称');
    return;
  }
  try {
    const current = await XGFStorage.getState();
    await chrome.runtime.sendMessage({
      type: 'xgf:save_preset',
      name,
      settings: {
        ...snapshotSettings(),
        actionProfiles: XGFShared.sanitizeActionProfiles(current.settings?.actionProfiles || XGFShared.buildDefaultSettings().actionProfiles)
      }
    });
    await load();
    $('#presetSelect').value = name;
    syncPresetButtons();
    syncPresetJson();
    status.textContent = L(`Preset saved: ${name}`, `已保存预设：${name}`);
  } catch (e) {
    status.textContent = L(`Save preset failed: ${e}`, `保存预设失败：${e}`);
  }
});

$('#applyPreset').addEventListener('click', async () => {
  const name = $('#presetSelect').value;
  if (!name) return;
  try {
    await chrome.runtime.sendMessage({ type: 'xgf:apply_preset', name });
    await chrome.runtime.sendMessage({ type: 'xgf:refresh_alarm' });
    await load();
    $('#presetSelect').value = name;
    syncPresetButtons();
    syncPresetJson();
    status.textContent = L(`Preset applied: ${name}`, `已应用预设：${name}`);
  } catch (e) {
    status.textContent = L(`Apply preset failed: ${e}`, `应用预设失败：${e}`);
  }
});

$('#deletePreset').addEventListener('click', async () => {
  const name = $('#presetSelect').value;
  if (!name) return;
  try {
    await chrome.runtime.sendMessage({ type: 'xgf:delete_preset', name });
    await load();
    status.textContent = L(`Preset deleted: ${name}`, `已删除预设：${name}`);
  } catch (e) {
    status.textContent = L(`Delete preset failed: ${e}`, `删除预设失败：${e}`);
  }
});

$('#presetSelect').addEventListener('change', () => {
  syncPresetButtons();
  syncPresetJson();
});

$('#themeMode').addEventListener('change', previewTheme);
$('#accentColor').addEventListener('change', previewTheme);

$('#uiLanguage').addEventListener('change', () => {
  const nextLang = $('#uiLanguage').value || 'en';
  const currentTemplate = $('#commentTemplate').value.trim();
  const currentDefault = defaultCommentTemplate(currentLang(liveSettings || {}));
  if (!currentTemplate || currentTemplate === currentDefault) {
    $('#commentTemplate').value = defaultCommentTemplate(nextLang);
  }
  liveSettings = { ...(liveSettings || {}), uiLanguage: nextLang };
  applyLanguageToPage(liveSettings);
  previewTheme();
});

$('#copyPreset').addEventListener('click', async () => {
  const json = $('#presetJson').value.trim();
  if (!json) {
    status.textContent = L('Please select a preset first', '请先选择一个预设');
    return;
  }
  try {
    await navigator.clipboard.writeText(json);
    status.textContent = L('Preset JSON copied. You can send it to others.', '预设 JSON 已复制，可直接发送给别人');
  } catch (e) {
    status.textContent = L(`Copy failed: ${e}`, `复制失败：${e}`);
  }
});

$('#loadPresetJson').addEventListener('click', async () => {
  const json = $('#presetJson').value.trim();
  if (!json) {
    status.textContent = L('Paste a preset JSON first', '请粘贴预设 JSON');
    return;
  }
  try {
    const res = await chrome.runtime.sendMessage({ type: 'xgf:import_preset', payload: json });
    await load();
    if (res?.activePresetName) $('#presetSelect').value = res.activePresetName;
    syncPresetButtons();
    syncPresetJson();
    status.textContent = L('Preset imported', '预设已导入');
  } catch (e) {
    status.textContent = L(`Import failed: ${e}`, `导入失败：${e}`);
  }
});

async function recordAction(action) {
  try {
    status.textContent = L(`Starting ${action} recording…`, `正在启动${action}录制…`);
    const res = await chrome.runtime.sendMessage({ type: 'xgf:record_action', action });
    if (res?.ok) {
      status.textContent = L(`${action} recording started. Go back to X and perform that action once.`, `${action} 录制已开始，请回到 X 页面完成一次对应操作`);
    } else {
      status.textContent = res?.error || L(`${action} recording failed`, `${action} 录制失败`);
    }
  } catch (err) {
    status.textContent = L(`${action} recording failed: ${err}`, `${action}录制失败：${err}`);
  }
}

$('#recordLike').addEventListener('click', () => recordAction('like'));
$('#recordRepost').addEventListener('click', () => recordAction('repost'));
$('#recordComment').addEventListener('click', () => recordAction('comment'));
$('#recordFollow').addEventListener('click', () => recordAction('follow'));

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local' || !changes.xgf_state) return;
  load().catch(() => {});
});

load().then(syncPresetButtons).catch(err => { status.textContent = L(`Load failed: ${err}`, `加载失败：${err}`); });
