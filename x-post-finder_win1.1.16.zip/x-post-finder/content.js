/* global chrome, XGFShared */
(() => {
  const seenIds = new Set();
  let lastUrl = location.href;
  let observerStarted = false;
  let scanTimer = null;

  let recordingSession = null;
  let recordTimer = null;
  let recordCommitTimer = null;
  let observerInstance = null;
  let contentPaused = false;

  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  function getArticleNodes(root = document) {
    const nodes = Array.from(root.querySelectorAll('article[data-testid="tweet"], article[role="article"]'));
    return nodes;
  }

  function extractHandleFromUrl(url) {
    try {
      const u = new URL(url, location.origin);
      const parts = u.pathname.split('/').filter(Boolean);
      if (parts.length >= 3 && parts[1] === 'status') {
        return { handle: parts[0], tweetId: parts[2] };
      }
      if (parts.length >= 4 && parts[0] === 'i' && parts[2] === 'status') {
        return { handle: '', tweetId: parts[3] };
      }
      if (parts.length >= 2 && parts[0] === 'status') {
        return { handle: '', tweetId: parts[1] };
      }
    } catch {}
    return { handle: '', tweetId: '' };
  }

  function parseCount(text) {
    if (!text) return 0;
    const s = String(text).replace(/,/g, '').trim().toLowerCase();
    const m = s.match(/^(\d+(?:\.\d+)?)([km])?$/);
    if (!m) {
      const n = Number.parseInt(s, 10);
      return Number.isFinite(n) ? n : 0;
    }
    let n = Number.parseFloat(m[1]);
    if (m[2] === 'k') n *= 1000;
    if (m[2] === 'm') n *= 1000000;
    return Math.round(n);
  }

  function parseTweet(article) {
    const statusLink = article.querySelector('a[href*="/status/"]');
    if (!statusLink) return null;

    const url = new URL(statusLink.getAttribute('href'), location.origin).href;
    const { handle, tweetId } = extractHandleFromUrl(url);
    if (!tweetId) return null;

    const authorNode = article.querySelector('[data-testid="User-Name"]') || article.querySelector('div[dir="ltr"]');
    const textNode = article.querySelector('[data-testid="tweetText"]');
    const timeNode = article.querySelector('time');
    const media = article.querySelector('[data-testid="tweetPhoto"], [data-testid="videoPlayer"]');
    const pinned = Array.from(article.querySelectorAll('span')).some(el => /pinned/i.test(el.textContent || ''));
    const verified = article.querySelector('[data-testid="icon-verified"]') !== null ||
      Array.from(article.querySelectorAll('svg')).some(el => /verified/i.test(el.getAttribute('aria-label') || ''));

    const metrics = { likes: 0, reposts: 0, replies: 0, views: 0 };
    const buttons = Array.from(article.querySelectorAll('[data-testid$="-count"]'));
    for (const el of buttons) {
      const tid = el.getAttribute('data-testid') || '';
      const value = parseCount(el.textContent || el.getAttribute('aria-label') || '0');
      if (/reply/.test(tid)) metrics.replies = value;
      if (/retweet|repost/.test(tid)) metrics.reposts = value;
      if (/like/.test(tid)) metrics.likes = value;
      if (/view/.test(tid)) metrics.views = value;
    }

    const authorText = XGFShared.normalizeText(authorNode?.textContent || '');
    let text = XGFShared.normalizeText(textNode?.innerText || textNode?.textContent || '');
    if (!text) {
      const cloned = article.cloneNode(true);
      cloned.querySelectorAll('a, button, svg, img, video, time').forEach(node => node.remove());
      text = XGFShared.normalizeText(cloned.innerText || cloned.textContent || '');
    }
    const timestamp = timeNode?.getAttribute('datetime') || null;
    const authorMatch = authorText.match(/(@[\w_]+)/);

    return {
      id: tweetId,
      url,
      handle: handle || (authorMatch ? authorMatch[1] : ''),
      author: authorText,
      title: authorText,
      text,
      timestamp,
      createdAt: timestamp ? new Date(timestamp).getTime() : Date.now(),
      hasMedia: Boolean(media),
      isPinned: pinned,
      isVerifiedAuthor: verified,
      metrics,
      raw: { authorText }
    };
  }

  function parseVisibleTweets(root = document) {
    const articles = getArticleNodes(root);
    const tweets = [];
    for (const article of articles) {
      const tweet = parseTweet(article);
      if (!tweet || !tweet.id || seenIds.has(tweet.id)) continue;
      seenIds.add(tweet.id);
      tweets.push(tweet);
    }
    return tweets;
  }

  async function sendMatches(tweets, reason = 'scan') {
    if (contentPaused || !tweets.length) return [];
    if (!await canScanBySettings()) return [];
    return await chrome.runtime.sendMessage({
      type: 'xgf:candidates',
      reason,
      tweets,
      pageUrl: location.href,
    });
  }

  async function scanNow(reason = 'manual') {
    if (contentPaused) return [];
    if (!await canScanBySettings()) return [];
    if (location.href !== lastUrl) {
      seenIds.clear();
      lastUrl = location.href;
    }

    const tweets = parseVisibleTweets(document);
    if (contentPaused || !tweets.length) return [];

    await sendMatches(tweets, reason);
    return tweets;
  }

  async function startObserver() {
    if (observerStarted || contentPaused) return;
    const allowed = await canScanBySettings(true);
    if (!allowed) {
      clearTimeout(scanTimer);
      scanTimer = setTimeout(() => {
        if (!contentPaused && !observerStarted) startObserver().catch(() => {});
      }, 5000);
      return;
    }
    observerStarted = true;

    observerInstance = new MutationObserver(() => {
      if (contentPaused) return;
      clearTimeout(scanTimer);
      scanTimer = setTimeout(() => {
        if (!contentPaused) scanNow('observer').catch(() => {});
      }, 1500);
    });

    observerInstance.observe(document.documentElement || document.body, { childList: true, subtree: true });
    if (!contentPaused) scanNow('init').catch(() => {});
  }

  function stopLocalTasks() {
    contentPaused = true;
    observerStarted = false;
    try { observerInstance?.disconnect(); } catch {}
    observerInstance = null;
    if (scanTimer) clearTimeout(scanTimer);
    if (recordTimer) clearTimeout(recordTimer);
    if (recordCommitTimer) clearTimeout(recordCommitTimer);
    scanTimer = null;
    recordTimer = null;
    recordCommitTimer = null;
    recordingSession = null;
  }

  function resumeLocalTasks() {
    contentPaused = false;
    if (!observerStarted) startObserver();
  }

  let scanPermissionCache = { at: 0, allowed: false };

  async function canScanBySettings(forceRefresh = false) {
    if (contentPaused) return false;
    if (!forceRefresh && Date.now() - scanPermissionCache.at < 5000) {
      return scanPermissionCache.allowed;
    }
    try {
      const res = await chrome.runtime.sendMessage({ type: 'xgf:get_state' });
      const s = res?.state?.settings || XGFShared.buildDefaultSettings();
      scanPermissionCache = {
        at: Date.now(),
        allowed: !!s.enabled && !!s.autoSearch && !s.searchPaused
      };
    } catch {
      // Fallback to the last known value; if we have never checked, stay conservative.
      scanPermissionCache = {
        at: Date.now(),
        allowed: false
      };
    }
    return scanPermissionCache.allowed;
  }

  function isUsableElement(el) {
    if (!el) return false;
    try {
      const style = window.getComputedStyle(el);
      if (!style || style.display === 'none' || style.visibility === 'hidden' || style.pointerEvents === 'none') return false;
    } catch {}
    if (el.disabled) return false;
    if (el.getAttribute?.('aria-hidden') === 'true') return false;
    if (el.closest?.('[aria-hidden="true"]')) return false;
    return true;
  }

  function resolveClickableTarget(el) {
    if (!el) return null;
    return el.closest('button, [role="button"], a, input, textarea, [contenteditable="true"], [tabindex]:not([tabindex="-1"])') || el;
  }

  function dispatchClickLikeMouse(el) {
    if (!el) return false;
    try {
      const opts = { bubbles: true, cancelable: true, view: window, composed: true };
      el.dispatchEvent(new PointerEvent('pointerdown', { ...opts, pointerId: 1, pointerType: 'mouse', isPrimary: true }));
      el.dispatchEvent(new MouseEvent('mousedown', opts));
      el.dispatchEvent(new PointerEvent('pointerup', { ...opts, pointerId: 1, pointerType: 'mouse', isPrimary: true }));
      el.dispatchEvent(new MouseEvent('mouseup', opts));
      el.dispatchEvent(new MouseEvent('click', opts));
      return true;
    } catch {
      try {
        el.click?.();
        return true;
      } catch {}
    }
    return false;
  }

  async function clickBySelectors(root, selectors) {
    const scope = root || document;
    for (const selector of selectors || []) {
      try {
        const found = scope.querySelector(selector);
        const btn = resolveClickableTarget(found);
        if (btn && isUsableElement(btn)) {
          try { btn.scrollIntoView({ block: 'center', inline: 'center', behavior: 'instant' }); } catch {}
          try { btn.focus?.(); } catch {}
          if (dispatchClickLikeMouse(btn)) return btn;
        }
      } catch {}
    }
    return null;
  }

  function safeCss(v) {
    return typeof CSS !== 'undefined' && CSS.escape ? CSS.escape(String(v)) : String(v).replace(/["\\]/g, '\\$&');
  }

  function buildSelectorCandidates(el) {
    if (!el || !el.tagName) return [];
    const out = [];
    const tag = el.tagName.toLowerCase();
    const testId = el.getAttribute('data-testid');
    const aria = el.getAttribute('aria-label');
    const title = el.getAttribute('title');
    const role = el.getAttribute('role');
    const name = el.getAttribute('name');
    const href = el.getAttribute('href');
    const text = XGFShared.normalizeText(el.textContent || '');
    const isStatusLink = typeof href === 'string' && /\/status\//.test(href);

    const push = sel => {
      if (sel && !out.includes(sel)) out.push(sel);
    };

    if (testId) push(`[data-testid="${safeCss(testId)}"]`);
    if (aria) push(`[aria-label="${safeCss(aria)}"]`);
    if (title) push(`[title="${safeCss(title)}"]`);
    if (name) push(`[name="${safeCss(name)}"]`);
    if (el.id) push(`#${safeCss(el.id)}`);
    if (isStatusLink) push(`${tag}[href*="/status/"]`);
    if (href && tag === 'a' && !isStatusLink) {
      try {
        const normalizedHref = new URL(href, location.origin).href;
        push(`a[href="${safeCss(normalizedHref)}"]`);
      } catch {}
    }
    if (role) push(`${tag}[role="${safeCss(role)}"]`);
    if (text) {
      const trimmed = text.slice(0, 28);
      if (trimmed) push(`${tag}[aria-label*="${safeCss(trimmed)}"]`);
    }

    const path = [];
    let node = el;
    while (node && node !== document.body && path.length < 4) {
      let seg = node.tagName ? node.tagName.toLowerCase() : '';
      if (!seg) break;
      if (node.id) {
        seg += `#${safeCss(node.id)}`;
        path.unshift(seg);
        break;
      }
      const classes = Array.from(node.classList || [])
        .filter(cls => cls && !/^css-/.test(cls))
        .slice(0, 2)
        .map(cls => `.${safeCss(cls)}`);
      if (classes.length) seg += classes.join('');
      const parent = node.parentElement;
      if (parent) {
        const sameTag = Array.from(parent.children).filter(child => child.tagName === node.tagName);
        if (sameTag.length > 1) {
          seg += `:nth-of-type(${sameTag.indexOf(node) + 1})`;
        }
      }
      path.unshift(seg);
      node = parent;
    }
    if (path.length) push(path.join(' > '));

    return out.slice(0, 10);
  }

  function findEditableBox(root = document) {
    return root.querySelector(
      '[role="dialog"] [data-testid="tweetTextarea_0"], [role="dialog"] [data-testid="tweetTextarea_1"], ' +
      '[role="dialog"] div[role="textbox"][contenteditable="true"], ' +
      'div[data-testid="tweetTextarea_0"], div[data-testid="tweetTextarea_1"], ' +
      'div[role="textbox"][contenteditable="true"]'
    );
  }

  function insertTextIntoEditable(el, text) {
    if (!el) return false;
    const value = String(text ?? '');

    try { el.focus(); } catch {}

    try {
      if (el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement) {
        const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
        setter?.call(el, value);
        if (!setter) el.value = value;
      } else if (el.isContentEditable) {
        const selection = window.getSelection();
        const range = document.createRange();
        range.selectNodeContents(el);
        range.collapse(false);
        selection?.removeAllRanges();
        selection?.addRange(range);
        if (!document.execCommand('insertText', false, value)) {
          el.textContent = value;
        }
      } else {
        el.textContent = value;
      }
    } catch {
      try { el.textContent = value; } catch {}
    }

    try {
      el.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, inputType: 'insertText', data: value }));
    } catch {
      el.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
    }
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }

  async function getSettings() {
    const res = await chrome.runtime.sendMessage({ type: 'xgf:get_state' });
    return res?.state?.settings || XGFShared.buildDefaultSettings();
  }

  function defaultSelectorsForAction(action) {
    if (action === 'like') return [
      '[data-testid="like"]',
      'button[aria-label*="Like"]',
      'button[aria-label*="点赞"]:not([aria-label*="取消"])',
      'button[aria-label*="赞"]:not([aria-label*="取消"])'
    ];
    if (action === 'repost') return ['[data-testid="retweet"]', '[data-testid="repost"]', 'button[aria-label*="Repost"]', 'button[aria-label*="转发"]'];
    if (action === 'comment') return ['[data-testid="reply"]', 'button[aria-label*="Reply"]', 'button[aria-label*="回复"]'];
    if (action === 'follow') return [
      '[data-testid="follow"]',
      'button[aria-label*="Follow"]',
      'button[aria-label*="关注"]:not([aria-label*="取消"])',
      'div[role="button"][data-testid="follow"]',
      'div[role="button"][aria-label*="Follow"]'
    ];
    return [];
  }

  function defaultTextBoxSelectors() {
    return [
      '[role="dialog"] [data-testid="tweetTextarea_0"]',
      '[role="dialog"] [data-testid="tweetTextarea_1"]',
      '[role="dialog"] div[role="textbox"][contenteditable="true"]',
      'div[data-testid="tweetTextarea_0"]',
      'div[data-testid="tweetTextarea_1"]',
      'div[role="textbox"][contenteditable="true"]'
    ];
  }

  function defaultConfirmSelectorsForRepost() {
    return [
      '[role="dialog"] [data-testid="retweetConfirm"]',
      '[role="dialog"] button[aria-label*="Repost"]',
      '[role="dialog"] button[aria-label*="转发"]',
      '[role="dialog"] div[role="button"][data-testid="retweetConfirm"]',
      'button[data-testid="retweetConfirm"]'
    ];
  }

  function getArticleForCurrentUrl() {
    return Array.from(getArticleNodes(document)).find(a => {
      const link = a.querySelector('a[href*="/status/"]');
      if (!link) return false;
      return XGFShared.normalizeTweetUrl(new URL(link.getAttribute('href'), location.origin).href) === XGFShared.normalizeTweetUrl(location.href);
    }) || null;
  }

  function closestActionElement(target) {
    if (!(target instanceof Element)) return null;
    const root = target.closest('article[data-testid="tweet"]') || document;
    const actionLike = target.closest('[data-testid], button, div[role="button"], a, span');
    if (!actionLike) return null;
    return actionLike.closest('button, div[role="button"], a, [data-testid]') || actionLike;
  }

  function isLikelyActionElement(action, el) {
    if (!el) return false;
    const testId = String(el.getAttribute?.('data-testid') || '').toLowerCase();
    const aria = String(el.getAttribute?.('aria-label') || '').toLowerCase();
    const text = XGFShared.lower(el.textContent || '');
    const blob = `${testId} ${aria} ${text}`;
    if (action === 'like') return (/like|点赞|赞/.test(blob)) && !/unlike|取消赞|取消点赞/.test(blob);
    if (action === 'repost') return /retweet|repost|转发/.test(blob);
    if (action === 'follow') return (/follow|关注/.test(blob)) && !/unfollow|取消关注/.test(blob);
    if (action === 'comment') return /reply|comment|回复/.test(blob);
    return false;
  }

  function buildActionProfile(action, el, extra = {}) {
    return {
      kind: action,
      selectors: buildSelectorCandidates(el),
      recordedAt: Date.now(),
      ...extra
    };
  }

  async function commitRecordedProfile(action, profile) {
    try {
      return await chrome.runtime.sendMessage({
        type: 'xgf:commit_recorded_action',
        action,
        profile
      });
    } catch (err) {
      return { ok: false, error: String(err) };
    }
  }

  function clearRecording(keepSession = false) {
    if (!keepSession) recordingSession = null;
    if (recordTimer) clearTimeout(recordTimer);
    if (recordCommitTimer) clearTimeout(recordCommitTimer);
    recordTimer = null;
    recordCommitTimer = null;
  }

  function scheduleCommentCapture() {
    if (!recordingSession || recordingSession.action !== 'comment') return;
    if (recordCommitTimer) clearTimeout(recordCommitTimer);
    recordCommitTimer = setTimeout(async () => {
      if (!recordingSession || recordingSession.action !== 'comment') return;
      const dialog = document.querySelector('[role="dialog"]') || document;
      const box = findEditableBox(dialog);
      const sendBtn = dialog.querySelector('[data-testid="tweetButtonInline"], [data-testid="tweetButton"], button[type="submit"]');

      if (!recordingSession.replySelectors || !recordingSession.replySelectors.length || !box) {
        recordCommitTimer = setTimeout(scheduleCommentCapture, 700);
        return;
      }

      const profile = {
        kind: 'comment',
        replySelectors: recordingSession.replySelectors,
        textBoxSelectors: [...buildSelectorCandidates(box), ...defaultTextBoxSelectors()],
        sendSelectors: sendBtn ? buildSelectorCandidates(sendBtn) : ['[data-testid="tweetButtonInline"]', '[data-testid="tweetButton"]', 'button[type="submit"]'],
        recordedAt: Date.now()
      };

      const saved = await commitRecordedProfile('comment', profile);
      if (saved?.ok) {
        clearRecording();
      } else {
        recordCommitTimer = setTimeout(scheduleCommentCapture, 700);
      }
    }, 800);
  }

  function scheduleRepostCapture() {
    if (!recordingSession || recordingSession.action !== 'repost') return;
    if (recordCommitTimer) clearTimeout(recordCommitTimer);
    recordCommitTimer = setTimeout(async () => {
      if (!recordingSession || recordingSession.action !== 'repost') return;
      const dialog = document.querySelector('[role="dialog"]') || document;
      const confirmEl = dialog.querySelector(
        '[data-testid="retweetConfirm"], button[aria-label*="Repost"], button[aria-label*="转发"], div[role="button"][data-testid="retweetConfirm"]'
      );

      if (!recordingSession.triggerSelectors || !recordingSession.triggerSelectors.length || !confirmEl) {
        recordCommitTimer = setTimeout(scheduleRepostCapture, 700);
        return;
      }

      const profile = {
        kind: 'repost',
        selectors: recordingSession.triggerSelectors,
        confirmSelectors: buildSelectorCandidates(confirmEl).concat(defaultConfirmSelectorsForRepost()),
        recordedAt: Date.now()
      };

      const saved = await commitRecordedProfile('repost', profile);
      if (saved?.ok) {
        clearRecording();
      } else {
        recordCommitTimer = setTimeout(scheduleRepostCapture, 700);
      }
    }, 900);
  }

  function startRecordingSession(action) {
    clearRecording();
    recordingSession = {
      action,
      startedAt: Date.now(),
      replySelectors: [],
      stage: action === 'comment' ? 'await-reply' : 'await-click'
    };
    return recordingSession;
  }

  async function onDocumentClick(event) {
    if (!recordingSession) return;
    const action = recordingSession.action;
    const targetEl = closestActionElement(event.target);
    if (!targetEl) return;

    if (action === 'comment') {
      if (recordingSession.stage !== 'await-reply') return;
      if (!isLikelyActionElement('comment', targetEl)) return;
      recordingSession.replySelectors = buildSelectorCandidates(targetEl);
      recordingSession.stage = 'await-dialog';
      scheduleCommentCapture();
      return;
    }

    if (action === 'repost') {
      if (recordingSession.stage !== 'await-click') return;
      if (!isLikelyActionElement('repost', targetEl)) return;
      recordingSession.triggerSelectors = buildSelectorCandidates(targetEl);
      recordingSession.stage = 'await-confirm';
      scheduleRepostCapture();
      return;
    }

    if (!isLikelyActionElement(action, targetEl)) return;
    const profile = buildActionProfile(action, targetEl);
    const saved = await commitRecordedProfile(action, profile);
    if (saved?.ok) clearRecording();
  }

  function startRecordingListeners() {
    document.addEventListener('click', onDocumentClick, true);
  }

  async function recordAction(action) {
    return { ok: false, error: '请使用插件窗口里的“录制”按钮启动录制模式' };
  }

  async function performAction(payload) {
    const { action, tweetUrl, comment } = payload || {};
    const targetUrl = tweetUrl || location.href;
    const settings = await getSettings();
    const actionProfiles = XGFShared.sanitizeActionProfiles(settings.actionProfiles);

    const normalizedTargetUrl = XGFShared.normalizeTweetUrl(targetUrl);
    const article = Array.from(getArticleNodes(document)).find(a => {
      const link = a.querySelector('a[href*="/status/"]');
      if (!link) return false;
      return XGFShared.normalizeTweetUrl(new URL(link.getAttribute('href'), location.origin).href) === normalizedTargetUrl;
    }) || (normalizedTargetUrl === XGFShared.normalizeTweetUrl(location.href) ? getArticleForCurrentUrl() : null);

    if (!article && action !== 'open' && action !== 'copy_comment') {
      return { ok: false, error: '未找到目标推文，请先打开原帖' };
    }

    const root = article || document;

    if (action === 'open') {
      window.open(targetUrl, '_blank', 'noopener,noreferrer');
      return { ok: true };
    }

    if (action === 'like') {
      const profile = actionProfiles.like;
      const selectors = [...(profile?.selectors || []), ...defaultSelectorsForAction('like')];
      const btn = await clickBySelectors(root, selectors);
      if (btn) return { ok: true, state: 'done' };
      const alreadyLiked = root.querySelector('[data-testid="unlike"], button[aria-label*="Unlike"], button[aria-label*="取消赞"], button[aria-label*="取消点赞"]');
      if (alreadyLiked) return { ok: true, pending: true, pendingKind: 'already_done', state: 'already_done', message: '该帖子已点赞，无需重复操作' };
      return { ok: false, error: '未找到点赞按钮' };
    }

    if (action === 'repost') {
      const profile = actionProfiles.repost || {};
      const selectors = [...(profile?.selectors || []), ...defaultSelectorsForAction('repost')];
      const trigger = await clickBySelectors(root, selectors);
      if (!trigger) return { ok: false, error: '未找到转发按钮' };

      await sleep(700);

      const dialog = document.querySelector('[role="dialog"]') || document;
      const confirmSelectors = [...(profile.confirmSelectors || []), ...defaultConfirmSelectorsForRepost()];
      const confirm = await clickBySelectors(dialog, confirmSelectors);
      return confirm
        ? { ok: true, state: 'done' }
        : { ok: true, pending: true, pendingKind: 'manual_confirm', state: 'manual_confirm', message: '已打开转发菜单，请手动确认' };
    }

    if (action === 'follow') {
      const profile = actionProfiles.follow;
      const selectors = [...(profile?.selectors || []), ...defaultSelectorsForAction('follow')];
      const btn = await clickBySelectors(root, selectors);
      if (btn) return { ok: true, state: 'done' };
      const alreadyFollowed = root.querySelector('[data-testid="unfollow"], button[aria-label*="Unfollow"], button[aria-label*="取消关注"]');
      if (alreadyFollowed) return { ok: true, pending: true, pendingKind: 'already_done', state: 'already_done', message: '该账号已关注，无需重复操作' };
      return { ok: false, error: '未找到关注按钮' };
    }

    if (action === 'comment') {
      const profile = actionProfiles.comment || {};
      const replySelectors = [...(profile.replySelectors || []), ...defaultSelectorsForAction('comment')];
      const replyBtn = await clickBySelectors(root, replySelectors);
      if (!replyBtn) return { ok: false, error: '未找到回复按钮' };

      await sleep(900);

      const dialog = document.querySelector('[role="dialog"]') || document;
      const box = await clickBySelectors(dialog, profile.textBoxSelectors || defaultTextBoxSelectors());
      const resolvedBox = box || findEditableBox(dialog);

      if (!resolvedBox || typeof comment !== 'string') return { ok: false, error: '未找到评论输入框' };

      if (!insertTextIntoEditable(resolvedBox, comment)) {
        return { ok: false, error: '评论输入失败' };
      }

      await sleep(400);

      const sendSelectors = [...(profile.sendSelectors || []), '[data-testid="tweetButtonInline"]', '[data-testid="tweetButton"]', 'button[type="submit"]'];
      const sendBtn = await clickBySelectors(dialog, sendSelectors);
      if (sendBtn) {
        return { ok: true, state: 'done' };
      }

      return { ok: true, pending: true, pendingKind: 'manual_send', state: 'manual_send', message: '评论内容已填入，请手动确认发送' };
    }

    if (action === 'copy_comment') {
      const text = comment || '';
      await navigator.clipboard.writeText(text);
      return { ok: true };
    }

    return { ok: false, error: '未知动作' };
  }

  async function autoSearchCycle(options = {}) {
    if (contentPaused) return [];
    if (location.href !== lastUrl) {
      seenIds.clear();
      lastUrl = location.href;
    }

    const maxResults = Math.max(1, Number(options.maxResults || 200));
    const scrollCycles = Math.max(1, Number(options.scrollCycles || 4));
    const delayMs = Math.max(300, Number(options.delayMs || 1200));
    const collected = [];

    for (let i = 0; i < scrollCycles; i += 1) {
      const tweets = parseVisibleTweets(document);
      if (tweets.length) {
        await sendMatches(tweets, i === 0 ? 'auto_search_init' : 'auto_search_scroll');
        collected.push(...tweets);
      }
      if (collected.length >= maxResults) break;

      window.scrollBy(0, Math.max(300, Math.floor(window.innerHeight * 0.9)));
      await sleep(delayMs);
    }

    const finalTweets = parseVisibleTweets(document);
    if (finalTweets.length) {
      await sendMatches(finalTweets, 'auto_search_final');
      collected.push(...finalTweets);
    }

    return collected;
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || !message.type) return;
    const fromExtension = sender?.id === chrome.runtime.id;

    // 只响应扩展内部消息，避免网页自身或外部来源抢答；后台通过 tabs.sendMessage 转发过来的消息也在这里处理。
    if (!fromExtension) return;

    if (message.type === 'xgf:stop_all') {
      stopLocalTasks();
      sendResponse({ ok: true });
      return;
    }

    if (message.type === 'xgf:resume_all') {
      resumeLocalTasks();
      sendResponse({ ok: true });
      return;
    }

    if (message.type === 'xgf:scan_visible') {
      scanNow('background')
        .then(items => sendResponse({ ok: true, count: items.length }))
        .catch(err => sendResponse({ ok: false, error: String(err) }));
      return true;
    }

    if (message.type === 'xgf:auto_search_cycle') {
      autoSearchCycle(message.options || {})
        .then(items => sendResponse({ ok: true, count: items.length }))
        .catch(err => sendResponse({ ok: false, error: String(err) }));
      return true;
    }

    if (message.type === 'xgf:start_record_action') {
      startRecordingSession(message.action);
      sendResponse({ ok: true, action: message.action });
      return;
    }

    if (message.type === 'xgf:perform_action') {
      performAction(message.payload)
        .then(result => sendResponse(result))
        .catch(err => sendResponse({ ok: false, error: String(err) }));
      return true;
    }
  });

  startObserver().catch(() => {});
  startRecordingListeners();
})();
