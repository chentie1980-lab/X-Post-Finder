/* global chrome, XGFStorage, XGFTemplates */
(() => {
  const $ = s => document.querySelector(s);
  let currentSettings = { uiLanguage: 'en' };

  const L = (enText, zhText) => (window.XGFShared?.uiText ? XGFShared.uiText(currentSettings, enText, zhText) : enText);

  function escapeHtml(str) {
    return String(str || '').replace(/[&<>"']/g, s => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[s]));
  }

  function setText(id, text) {
    const el = document.getElementById(id);
    if (el) el.textContent = text;
  }

  function applyPageLanguage(settings = {}) {
    currentSettings = settings || currentSettings || {};
    const lang = window.XGFShared?.getUILanguage ? XGFShared.getUILanguage(currentSettings) : 'en';
    document.documentElement.lang = lang === 'zh' ? 'zh-CN' : 'en';
    if (lang === 'zh') {
      document.title = 'X Post Finder · 收录列表';
      setText('pageTitle', '收录列表');
      setText('btnRefresh', '刷新');
      setText('btnClear', '清空全部');
      setText('btnOpenOptions', '设置');
      setText('lblCollected', '已收录');
      setText('lblScanned', '已扫描');
      setText('lblSearchState', '搜索状态');
      const filter = $('#filter');
      if (filter) filter.placeholder = '搜索作者、正文、URL 或分数…';
      setText('btnApplyFilter', '筛选');
      setText('recordLike', '录制点赞');
      setText('recordRepost', '录制转发');
      setText('recordComment', '录制评论');
      setText('recordFollow', '录制关注');
      setText('forceStop', '强制停止');
    } else {
      document.title = 'X Post Finder · Records';
      setText('pageTitle', 'Records');
      setText('btnRefresh', 'Refresh');
      setText('btnClear', 'Clear all');
      setText('btnOpenOptions', 'Settings');
      setText('lblCollected', 'Collected');
      setText('lblScanned', 'Scanned');
      setText('lblSearchState', 'Search status');
      const filter = $('#filter');
      if (filter) filter.placeholder = 'Search author, text, URL, or score…';
      setText('btnApplyFilter', 'Filter');
      setText('recordLike', 'Record like');
      setText('recordRepost', 'Record repost');
      setText('recordComment', 'Record comment');
      setText('recordFollow', 'Record follow');
      setText('forceStop', 'Force stop');
    }
  }

  async function getState() {
    try {
      const res = await chrome.runtime.sendMessage({ type: 'xgf:get_state' });
      if (res?.state) return res.state;
    } catch {}
    return await XGFStorage.getState();
  }

  function renderCandidate(item, statusEl) {
    const div = document.createElement('div');
    div.className = 'item';
    const title = item.author || item.handle || L('Unknown author', '未知作者');
    const text = item.text || '';
    const badgeClass = item.tag || 'low';
    const reasons = Array.isArray(item.reasons) ? item.reasons.slice(0, 4).map(r => XGFShared.localizeReason ? XGFShared.localizeReason(r, currentSettings) : r).join(' · ') : '';
    const defaultComment = (window.XGFTemplates?.buildCommentTemplate)
      ? XGFTemplates.buildCommentTemplate(item, currentSettings)
      : (item.commentTemplate || '');

    div.innerHTML = `
      <div class="item-top">
        <div>
          <div class="item-title">${escapeHtml(title)}</div>
          <div class="item-text">${escapeHtml(text)}</div>
        </div>
        <div class="badge ${badgeClass}">${item.score ?? 0} ${L('pts', '分')}</div>
      </div>
      <div class="meta">
        <span>${escapeHtml(item.url || '')}</span>
        <span>${escapeHtml(reasons)}</span>
        <span>${item.timestamp ? escapeHtml(String(item.timestamp)) : ''}</span>
      </div>
      <div class="actions">
        <button data-act="open">${L('Open original', '打开原帖')}</button>
        <button data-act="copy" class="secondary">${L('Copy comment template', '复制评论')}</button>
        <button data-act="like" class="secondary">${L('Like', '点赞')}</button>
        <button data-act="repost" class="secondary">${L('Repost', '转发')}</button>
        <button data-act="comment" class="secondary">${L('Comment', '评论')}</button>
        <button data-act="follow" class="secondary">${L('Follow', '关注')}</button>
        <button data-act="quad" class="secondary">${L('One-click all', '一键四连')}</button>
      </div>
    `;

    div.querySelectorAll('button').forEach(btn => {
      btn.addEventListener('click', async () => {
        const act = btn.dataset.act;
        const comment = item.commentTemplate || defaultComment;

        if (act === 'open') {
          if (item.url) chrome.tabs.create({ url: item.url, active: true });
          statusEl.textContent = L('Opened original post', '已打开原帖');
          return;
        }

        if (act === 'copy') {
          try {
            await navigator.clipboard.writeText(comment);
            statusEl.textContent = L('Comment template copied', '评论内容已复制');
          } catch (err) {
            statusEl.textContent = L(`Copy failed: ${err}`, `复制失败：${err}`);
          }
          return;
        }

        if (act === 'quad') {
          const result = await runQuadAction(item, comment);
          if (result.stop) {
            const res = result.res || {};
            if (res?.message) statusEl.textContent = res.message;
            else if (res?.error) statusEl.textContent = res.error;
            else statusEl.textContent = L(`${result.step} needs manual confirmation, the rest has been paused`, `${result.step} 需要人工确认，已暂停后续动作`);
            return;
          }
          const parts = [];
          if (result.completed?.length) parts.push(L(`Confirmed: ${result.completed.join(', ')}`, `已确认完成 ${result.completed.join('、')}`));
          if (result.skipped?.length) parts.push(L(`Skipped: ${result.skipped.join(', ')}`, `已跳过 ${result.skipped.join('、')}`));
          if (result.pending) {
            const pendingLabel = result.pending.step === 'comment'
              ? L('Comment awaits manual send', '评论待人工发送')
              : result.pending.step === 'repost'
                ? L('Repost awaits manual confirmation', '转发待人工确认')
                : L(`${result.pending.step} awaits manual confirmation`, `${result.pending.step} 待人工确认`);
            parts.push(result.pending.res?.message || pendingLabel);
          }
          statusEl.textContent = parts.length ? parts.join('；') : L('All done', '四连完成');
          return;
        }

        await doAction(act, item, comment, statusEl);
      });
    });

    return div;
  }

  async function doAction(action, item, comment, statusEl) {
    try {
      const res = await chrome.runtime.sendMessage({
        type: 'xgf:perform_action',
        payload: { action, tweetUrl: item.url, comment }
      });
      if (res?.ok && !res?.pending) {
        statusEl.textContent = L(`${action} executed`, `${action} 已执行`);
      } else if (res?.pending) {
        statusEl.textContent = res?.message || L(`${action} is pending confirmation`, `${action} 已进入待确认状态`);
      } else {
        statusEl.textContent = res?.error || L('Action failed', '动作失败');
      }
      return res;
    } catch (err) {
      statusEl.textContent = L(`${action} call failed: ${err}`, `${action} 调用失败：${err}`);
      return { ok: false, error: String(err) };
    }
  }

  async function runQuadAction(item, comment) {
    const steps = ['like', 'repost', 'follow', 'comment'];
    const completed = [];
    const skipped = [];

    for (const step of steps) {
      let res;
      try {
        res = await chrome.runtime.sendMessage({
          type: 'xgf:perform_action',
          payload: { action: step, tweetUrl: item.url, comment }
        });
      } catch (err) {
        return { stop: true, step, res: { ok: false, error: String(err) }, completed, skipped };
      }

      if (!res?.ok) {
        return { stop: true, step, res, completed, skipped };
      }

      if (res.pending && (res.pendingKind || res.state) === 'already_done') {
        skipped.push(step);
        continue;
      }

      if (res.pending) {
        return { stop: true, step, res, completed, skipped, pending: { step, res } };
      }

      completed.push(step);
    }

    return { stop: false, completed, skipped };
  }

  function applySearchState(state) {
    const s = state.settings || {};
    const label = (window.XGFShared?.describeSearchState)
      ? XGFShared.describeSearchState(s)
      : (!s.enabled ? L('Off', '已关闭') : s.forceStopped ? L('Force stopped', '强制停止中') : s.searchPaused ? L('Paused', '已暂停') : !s.autoSearch ? L('Auto search off', '自动搜索关闭') : L('Running', '运行中'));
    $('#statSearchState').textContent = label;
  }

  function render(cache) {
    const q = $('#filter').value.trim().toLowerCase();
    const items = cache.filter(item => {
      if (!q) return true;
      const hay = [
        item.author, item.handle, item.text, item.url, item.score, ...(item.reasons || [])
      ].join(' ').toLowerCase();
      return hay.includes(q);
    }).sort((a, b) => (b.score || 0) - (a.score || 0));

    const list = $('#list');
    list.innerHTML = '';
    for (const item of items) {
      list.appendChild(renderCandidate(item, $('#status')));
    }

    $('#statCount').textContent = String(items.length);
    $('#status').textContent = q
      ? (items.length ? L(`Showing ${items.length} filtered records`, `筛选后显示 ${items.length} 条记录`) : L('No matches', '暂无匹配记录'))
      : (items.length ? L(`Showing ${items.length} records`, `显示 ${items.length} 条记录`) : L('No matches', '暂无匹配记录'));
  }

  async function load() {
    const state = await getState();
    currentSettings = state.settings || {};
    if (window.XGFShared?.applyTheme) XGFShared.applyTheme(document.documentElement, currentSettings);
    applyPageLanguage(currentSettings);
    const cache = (state.candidates || []).filter(x => !x.hidden);
    $('#statCount').textContent = String(cache.length);
    $('#statScanned').textContent = String(state.stats?.scanned || 0);
    applySearchState(state);
    render(cache);
    return cache;
  }

  function setBootError(err) {
    const statusEl = $('#status');
    const list = $('#list');
    if (statusEl) statusEl.textContent = L(`Load failed: ${err}`, `加载失败：${err}`);
    if (list) {
      list.innerHTML = '';
      const box = document.createElement('div');
      box.className = 'item';
      box.textContent = L(`Records page failed to load: ${err}`, `收录页加载失败：${err}`);
      list.appendChild(box);
    }
  }

  async function boot() {
    const statusEl = $('#status');
    const list = $('#list');
    if (!statusEl || !list) throw new Error('Records page DOM was not loaded correctly');

    const refresh = () => load().catch(setBootError);
    $('#btnRefresh')?.addEventListener('click', refresh);
    $('#btnApplyFilter')?.addEventListener('click', () => load().catch(setBootError));
    $('#btnOpenOptions')?.addEventListener('click', () => chrome.runtime.openOptionsPage());
    $('#btnClear')?.addEventListener('click', async () => {
      await XGFStorage.clearCandidates();
      statusEl.textContent = L('All records cleared', '已清空全部收录');
      await load();
    });
    $('#filter')?.addEventListener('keydown', e => {
      if (e.key === 'Enter') load().catch(setBootError);
    });

    async function recordAction(action) {
      try {
        statusEl.textContent = L(`Starting ${action} recording…`, `正在启动${action}录制…`);
        const res = await chrome.runtime.sendMessage({ type: 'xgf:record_action', action });
        statusEl.textContent = res?.ok ? L(`${action} recording started. Go back to X and perform that action once.`, `${action} 录制已开始，请回到 X 页面完成一次对应操作`) : (res?.error || L(`${action} recording failed`, `${action} 录制失败`));
      } catch (err) {
        statusEl.textContent = L(`${action} recording failed: ${err}`, `${action} 录制失败：${err}`);
      }
    }

    $('#recordLike')?.addEventListener('click', () => recordAction('like'));
    $('#recordRepost')?.addEventListener('click', () => recordAction('repost'));
    $('#recordComment')?.addEventListener('click', () => recordAction('comment'));
    $('#recordFollow')?.addEventListener('click', () => recordAction('follow'));

    $('#forceStop')?.addEventListener('click', async () => {
      statusEl.textContent = L('Forcing stop…', '正在强制停止…');
      const res = await chrome.runtime.sendMessage({ type: 'xgf:force_stop', reason: 'matches' });
      if (res?.ok) {
        statusEl.textContent = L('Force stop applied: search, notifications, and page scanning are paused.', '已强制停止：搜索、通知和页面扫描已暂停');
      } else {
        statusEl.textContent = res?.error || L('Force stop failed', '强制停止失败');
      }
    });

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local' || !changes.xgf_state) return;
      load().catch(setBootError);
    });

    await load();
  }

  const start = () => boot().catch(setBootError);
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
