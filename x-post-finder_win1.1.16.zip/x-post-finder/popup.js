/* global chrome, XGFStorage, XGFTemplates */
(() => {
  const $ = sel => document.querySelector(sel);
  let currentSettings = XGFStorage?.buildDefaultSettings ? XGFStorage.buildDefaultSettings() : { uiLanguage: 'en' };

  const L = (enText, zhText) => (window.XGFShared?.uiText ? XGFShared.uiText(currentSettings, enText, zhText) : enText);

  function setText(id, text) {
    const el = document.getElementById(id);
    if (el) el.textContent = text;
  }

  function applyPopupLanguage(settings = {}) {
    currentSettings = settings || currentSettings || {};
    const lang = window.XGFShared?.getUILanguage ? XGFShared.getUILanguage(currentSettings) : 'en';
    document.documentElement.lang = lang === 'zh' ? 'zh-CN' : 'en';

    if (lang === 'zh') {
      document.title = 'X Post Finder';
      setText('pageTitle', 'X Post Finder');
      setText('btnRefresh', '刷新');
      setText('lblScanned', '已扫描');
      setText('lblMatched', '已收录');
      setText('lblSearchState', '搜索状态');
      setText('btnSearchNow', '立即搜索');
      setText('btnTogglePause', currentSettings.forceStopped || currentSettings.searchPaused ? '继续搜索' : '暂停搜索');
      setText('btnForceStop', '强制停止');
      setText('btnOpenMatches', '全部收录');
      setText('btnOpenOptions', '设置');
      setText('recordSectionTitle', '动作录制');
      setText('recordSectionHint', '先点录制，再回到 X 点一次对应按钮。');
      setText('recordLike', '录制点赞');
      setText('recordRepost', '录制转发');
      setText('recordComment', '录制评论');
      setText('recordFollow', '录制关注');
      setText('recentTitle', '最近发现');
      setText('btnClear', '清空记录');
    } else {
      document.title = 'X Post Finder';
      setText('pageTitle', 'X Post Finder');
      setText('btnRefresh', 'Refresh');
      setText('lblScanned', 'Scanned');
      setText('lblMatched', 'Collected');
      setText('lblSearchState', 'Search status');
      setText('btnSearchNow', 'Search now');
      setText('btnTogglePause', currentSettings.forceStopped || currentSettings.searchPaused ? 'Resume search' : 'Pause search');
      setText('btnForceStop', 'Force stop');
      setText('btnOpenMatches', 'All records');
      setText('btnOpenOptions', 'Settings');
      setText('recordSectionTitle', 'Action recording');
      setText('recordSectionHint', 'Click record, then go back to X and press the matching button once.');
      setText('recordLike', 'Record like');
      setText('recordRepost', 'Record repost');
      setText('recordComment', 'Record comment');
      setText('recordFollow', 'Record follow');
      setText('recentTitle', 'Recent finds');
      setText('btnClear', 'Clear records');
    }
  }

  function showFatalError(err) {
    const statusEl = $('#status');
    const listEl = $('#list');
    const message = err instanceof Error ? err.message : String(err);
    if (statusEl) statusEl.textContent = L(`Load failed: ${message}`, `加载失败：${message}`);
    if (listEl) {
      listEl.innerHTML = '';
      const box = document.createElement('div');
      box.className = 'item';
      box.textContent = L(`Popup failed to load: ${message}`, `弹窗加载失败：${message}`);
      listEl.appendChild(box);
    }
  }

  function escapeHtml(str) {
    return String(str || '').replace(/[&<>"']/g, s => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[s]));
  }

  async function getState() {
    try {
      const res = await chrome.runtime.sendMessage({ type: 'xgf:get_state' });
      if (res?.state) return res.state;
    } catch {}
    return await XGFStorage.getState();
  }

  function renderCandidate(item, statusEl) {
    const div = document.createElement('div');
    div.className = 'item';
    const badgeClass = item.tag || 'low';
    const title = item.author || item.handle || L('Unknown author', '未知作者');
    const text = item.text || '';
    const reasons = Array.isArray(item.reasons) ? item.reasons.slice(0, 3).map(r => XGFShared.localizeReason ? XGFShared.localizeReason(r, currentSettings) : r).join(' · ') : '';
    const defaultComment = (window.XGFTemplates?.buildCommentTemplate)
      ? XGFTemplates.buildCommentTemplate(item, currentSettings)
      : (item.commentTemplate || '');

    div.innerHTML = `
      <div class="item-top">
        <div>
          <div class="item-title">${escapeHtml(title)}</div>
          <div class="item-text">${escapeHtml(text.slice(0, 120))}${text.length > 120 ? '…' : ''}</div>
        </div>
        <div class="badge ${badgeClass}">${item.score ?? 0} ${L('pts', '分')}</div>
      </div>
      <div class="meta">${escapeHtml(reasons)}</div>
      <div class="actions">
        <button data-act="open">${L('Open original', '打开原帖')}</button>
        <button data-act="copy" class="secondary">${L('Copy comment template', '复制评论模板')}</button>
        <button data-act="like" class="secondary">${L('Like', '点赞')}</button>
        <button data-act="repost" class="secondary">${L('Repost', '转发')}</button>
        <button data-act="comment" class="secondary">${L('Comment', '评论')}</button>
        <button data-act="follow" class="secondary">${L('Follow', '关注')}</button>
        <button data-act="quad" class="secondary">${L('One-click all', '一键四连')}</button>
      </div>
    `;

    div.querySelectorAll('button').forEach(btn => {
      btn.addEventListener('click', async () => {
        const act = btn.dataset.act;
        const comment = item.commentTemplate || defaultComment;

        if (act === 'copy') {
          try {
            await navigator.clipboard.writeText(comment);
            statusEl.textContent = L('Comment template copied', '评论模板已复制');
          } catch (err) {
            statusEl.textContent = L(`Copy failed: ${err}`, `复制失败：${err}`);
          }
          return;
        }

        if (act === 'open') {
          if (item.url) chrome.tabs.create({ url: item.url, active: true });
          statusEl.textContent = L('Opened original post', '已打开原帖');
          return;
        }

        if (act === 'quad') {
          const result = await runQuadAction(item, comment);
          if (result.stop) {
            const res = result.res || {};
            if (res?.message) statusEl.textContent = res.message;
            else if (res?.error) statusEl.textContent = res.error;
            else statusEl.textContent = L(`${result.step} needs manual confirmation, the rest has been paused`, `${result.step} 需要人工确认，已暂停后续动作`);
            return;
          }
          const parts = [];
          if (result.completed?.length) parts.push(L(`Confirmed: ${result.completed.join(', ')}`, `已确认完成 ${result.completed.join('、')}`));
          if (result.skipped?.length) parts.push(L(`Skipped: ${result.skipped.join(', ')}`, `已跳过 ${result.skipped.join('、')}`));
          if (result.pending) {
            const pendingLabel = result.pending.step === 'comment'
              ? L('Comment awaits manual send', '评论待人工发送')
              : result.pending.step === 'repost'
                ? L('Repost awaits manual confirmation', '转发待人工确认')
                : L(`${result.pending.step} awaits manual confirmation`, `${result.pending.step} 待人工确认`);
            parts.push(result.pending.res?.message || pendingLabel);
          }
          statusEl.textContent = parts.length ? parts.join(' | ') : L('All done', '四连完成');
          return;
        }

        const payload = { action: act, tweetUrl: item.url, comment };
        const res = await chrome.runtime.sendMessage({ type: 'xgf:perform_action', payload });
        if (res?.ok && !res?.pending) statusEl.textContent = L(`${act} executed`, `${act} 已执行`);
        else if (res?.pending) statusEl.textContent = res?.message || L(`${act} is pending confirmation`, `${act} 已进入待确认状态`);
        else statusEl.textContent = res?.error || L('Action failed', '动作失败');
      });
    });

    return div;
  }

  async function runQuadAction(item, comment) {
    const steps = ['like', 'repost', 'follow', 'comment'];
    const completed = [];
    const skipped = [];

    for (const step of steps) {
      let res;
      try {
        res = await chrome.runtime.sendMessage({
          type: 'xgf:perform_action',
          payload: { action: step, tweetUrl: item.url, comment }
        });
      } catch (err) {
        return { stop: true, step, res: { ok: false, error: String(err) }, completed, skipped };
      }

      if (!res?.ok) {
        return { stop: true, step, res, completed, skipped };
      }

      if (res.pending && (res.pendingKind || res.state) === 'already_done') {
        skipped.push(step);
        continue;
      }

      if (res.pending) {
        return { stop: true, step, res, completed, skipped, pending: { step, res } };
      }

      completed.push(step);
    }

    return { stop: false, completed, skipped };
  }

  function updateStateBadge(state, elements) {
    const s = state.settings || {};
    const label = (window.XGFShared?.describeSearchState)
      ? XGFShared.describeSearchState(s)
      : (!s.enabled ? L('Off', '已关闭') : s.forceStopped ? L('Force stopped', '强制停止中') : s.searchPaused ? L('Paused', '已暂停') : !s.autoSearch ? L('Auto search off', '自动搜索关闭') : L('Running', '运行中'));
    elements.statSearchState.textContent = label;

    const pauseBtn = elements.btnTogglePause;
    if (pauseBtn) {
      pauseBtn.textContent = s.forceStopped || s.searchPaused ? L('Resume search', '继续搜索') : L('Pause search', '暂停搜索');
      pauseBtn.title = s.forceStopped
        ? L('Resume background auto search after clearing force stop', '解除强制停止并恢复后台自动搜索')
        : (s.searchPaused ? L('Resume background auto search', '恢复后台自动搜索') : L('Pause background auto search', '暂停后台自动搜索'));
    }
  }

  function render(state, elements) {
    const candidates = (state.candidates || []).filter(x => !x.hidden).sort((a, b) => (b.score || 0) - (a.score || 0));
    elements.statScanned.textContent = String(state.stats?.scanned || 0);
    elements.statMatched.textContent = String(candidates.length || 0);
    updateStateBadge(state, elements);
    elements.statusEl.textContent = candidates.length
      ? L(`Loaded ${candidates.length} highly relevant posts`, `已加载 ${candidates.length} 条高相关帖子`)
      : L('No results yet, waiting for scanning', '暂无结果，等待扫描');
    elements.list.innerHTML = '';
    for (const item of candidates.slice(0, 12)) {
      elements.list.appendChild(renderCandidate(item, elements.statusEl));
    }
    return candidates;
  }

  async function load(elements) {
    const state = await getState();
    currentSettings = state.settings || {};
    if (window.XGFShared?.applyTheme) XGFShared.applyTheme(document.documentElement, currentSettings);
    applyPopupLanguage(currentSettings);
    updateStateBadge(state, elements);
    render(state, elements);
  }

  function setBootError(elements, err) {
    if (elements?.statusEl) elements.statusEl.textContent = L(`Load failed: ${err}`, `加载失败：${err}`);
    if (elements?.list) {
      elements.list.innerHTML = '';
      const box = document.createElement('div');
      box.className = 'item';
      box.textContent = L(`Popup failed to load: ${err}`, `弹窗加载失败：${err}`);
      elements.list.appendChild(box);
    }
  }

  window.addEventListener('error', event => {
    showFatalError(event?.error || event?.message || 'Unknown script error');
  });

  window.addEventListener('unhandledrejection', event => {
    showFatalError(event?.reason || 'Unhandled promise rejection');
  });

  async function boot() {
    const elements = {
      list: $('#list'),
      statusEl: $('#status'),
      btnRefresh: $('#btnRefresh'),
      btnSearchNow: $('#btnSearchNow'),
      btnOpenOptions: $('#btnOpenOptions'),
      btnOpenMatches: $('#btnOpenMatches'),
      btnTogglePause: $('#btnTogglePause'),
      btnForceStop: $('#btnForceStop'),
      btnClear: $('#btnClear'),
      recordLike: $('#recordLike'),
      recordRepost: $('#recordRepost'),
      recordComment: $('#recordComment'),
      recordFollow: $('#recordFollow'),
      statScanned: $('#statScanned'),
      statMatched: $('#statMatched'),
      statSearchState: $('#statSearchState'),
    };

    if (!elements.list || !elements.statusEl) {
      throw new Error('Popup DOM was not loaded correctly');
    }

    const refresh = () => load(elements).catch(err => setBootError(elements, err));
    elements.btnRefresh?.addEventListener('click', refresh);

    elements.btnSearchNow?.addEventListener('click', async () => {
      try {
        elements.statusEl.textContent = L('Triggering background search…', '正在触发后台搜索…');
        const res = await chrome.runtime.sendMessage({ type: 'xgf:run_search' });
        if (res?.result?.skipped) {
          if (res.result.reason === 'stopped') {
            elements.statusEl.textContent = L('Background search is force-stopped. Resume it first.', '当前处于强制停止状态，请先恢复后台搜索');
          } else if (res.result.reason === 'paused') {
            elements.statusEl.textContent = L('Background search is paused, but a manual run is still allowed.', '当前处于暂停状态，但手动搜索仍可执行');
          } else if (res.result.reason === 'auto_search_off') {
            elements.statusEl.textContent = L('Background auto search is off and cannot run.', '后台自动搜索已关闭，无法运行');
          } else if (res.result.reason === 'disabled') {
            elements.statusEl.textContent = L('The extension is disabled and cannot run.', '插件已关闭，无法运行');
          } else {
            elements.statusEl.textContent = L(`Search not run: ${res.result.reason || 'unknown reason'}`, `搜索未执行：${res.result.reason || '未知原因'}`);
          }
        }
        await new Promise(r => setTimeout(r, 1200));
        await load(elements);
      } catch (err) {
        elements.statusEl.textContent = L(`Search failed: ${err}`, `搜索调用失败：${err}`);
      }
    });

    elements.btnOpenOptions?.addEventListener('click', () => chrome.runtime.openOptionsPage());
    elements.btnOpenMatches?.addEventListener('click', () => chrome.tabs.create({ url: chrome.runtime.getURL('matches.html') }));

    elements.btnTogglePause?.addEventListener('click', async () => {
      try {
        const state = await getState();
        const next = !state.settings?.searchPaused;
        await XGFStorage.updateSettings({ searchPaused: next });
        await chrome.runtime.sendMessage({ type: 'xgf:refresh_alarm' });
        elements.statusEl.textContent = next ? L('Background auto search paused', '已暂停后台自动搜索') : L('Background auto search resumed', '已恢复后台自动搜索');
        await load(elements);
      } catch (err) {
        elements.statusEl.textContent = L(`Toggle failed: ${err}`, `切换失败：${err}`);
      }
    });

    elements.btnForceStop?.addEventListener('click', async () => {
      try {
        elements.statusEl.textContent = L('Force stopping…', '正在强制停止…');
        const res = await chrome.runtime.sendMessage({ type: 'xgf:force_stop', reason: 'popup' });
        if (res?.ok) {
          elements.statusEl.textContent = L('Force stop applied: search, notifications, and page scanning are paused.', '已强制停止：搜索、通知和页面扫描已暂停');
          await load(elements);
        } else {
          elements.statusEl.textContent = res?.error || L('Force stop failed', '强制停止失败');
        }
      } catch (err) {
        elements.statusEl.textContent = L(`Force stop failed: ${err}`, `强制停止失败：${err}`);
      }
    });

    elements.btnClear?.addEventListener('click', async () => {
      try {
        await XGFStorage.clearCandidates();
        elements.statusEl.textContent = L('Records cleared', '记录已清空');
        await load(elements);
      } catch (err) {
        elements.statusEl.textContent = L(`Clear failed: ${err}`, `清空失败：${err}`);
      }
    });

    async function recordAction(action) {
      try {
        elements.statusEl.textContent = L(`Starting ${action} recording…`, `正在启动${action}录制…`);
        const res = await chrome.runtime.sendMessage({ type: 'xgf:record_action', action });
        if (res?.ok) {
          elements.statusEl.textContent = L(`${action} recording has started. Go back to X and perform that action once.`, `${action} 录制已开始，请回到 X 页面完成一次对应操作`);
        } else {
          elements.statusEl.textContent = res?.error || L(`${action} recording failed`, `${action} 录制失败`);
        }
      } catch (err) {
        elements.statusEl.textContent = L(`${action} recording failed: ${err}`, `${action}录制失败：${err}`);
      }
    }

    elements.recordLike?.addEventListener('click', () => recordAction('like'));
    elements.recordRepost?.addEventListener('click', () => recordAction('repost'));
    elements.recordComment?.addEventListener('click', () => recordAction('comment'));
    elements.recordFollow?.addEventListener('click', () => recordAction('follow'));

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local' || !changes.xgf_state) return;
      load(elements).catch(() => {});
    });

    await load(elements);
  }

  const start = () => boot().catch(err => {
    showFatalError(err);
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
